const serverless=require('serverless-http'),app=require('../../lib/server'),h=serverless(app);
exports.handler=(e,c)=>{e.path='/api'+e.path.replace(/^\/(\.netlify\/functions\/api|api)/,'');return h(e,c)};
